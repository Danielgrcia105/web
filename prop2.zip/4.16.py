N = int(input("Ingrese el número de números a procesar: "))

Numerador = 1

while Numerador <= N:
   
    numero = int(input(f"Ingrese el número natural positivo {Numerador}: "))

    cubo = numero ** 3

(f"El cubo de {numero} es: {cubo}")

Numerador += 1