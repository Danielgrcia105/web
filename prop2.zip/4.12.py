print("Billetes")

num_billetes_monedas = int(input("Ingrese el número de billetes y monedas: "))

contador = 1

while contador <= num_billetes_monedas:
    cantidad = int(input(f"Ingrese la cantidad del billete o moneda {contador}: "))
    valor = float(input(f"Ingrese el valor del billete o moneda {contador}: "))
    
    subtotal = cantidad * valor
    total = subtotal
    
    contador += 1

print(f"El total en la caja registradora es: {total}")