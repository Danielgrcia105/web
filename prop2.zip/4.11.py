x = float(input("Ingrese el valor de x: "))


resultado = 1  

termino = 1    


n = 1


while abs(termino) > 1e-8:
    
    termino = (termino * x) / n


    resultado += termino

    n += 1


print(f"e^{x} es aproximadamente {resultado:.8f}")