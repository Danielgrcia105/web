
i = 0.15  
A = 1500  

n = int(input("Ingrese el número de años: "))

P = A / (1 + i)**n

print(f"El valor actual de la inversión después de {n} años es: {P:.2f}")