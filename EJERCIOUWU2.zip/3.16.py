def calcular_bono(salario_minimo, puntos):

    if puntos <= 100:

        bono = salario_minimo

    elif puntos <= 150:

        bono = 2 * salario_minimo

    else:

        bono = 3 * salario_minimo

    return bono


salario_minimo = float(input("Ingrese el valor del salario mínimo: "))

puntos_profesor = int(input("Ingrese los puntos del profesor: "))


monto_bono = calcular_bono(salario_minimo, puntos_profesor)


print(f"El monto del bono para el profesor es: {monto_bono} salarios mínimos.")