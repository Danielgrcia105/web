def determinar_paquete(dinero_recibido):

    if dinero_recibido >= 50000:

        return "Paquete A: Televisión, modular, 3 pares de zapatos, 5 camisas y 5 pantalones"

    elif dinero_recibido >= 20000:

        return "Paquete B: Grabadora, 3 pares de zapatos, 5 camisas y 5 pantalones"

    elif dinero_recibido >= 10000:

        return "Paquete C: 2 pares de zapatos, 3 camisas y 3 pantalones"

    else:

        return "Paquete D: 1 par de zapatos, 2 camisas y 2 pantalones"

 

# ya aplicado y calculado 

dinero_recibido = float(input("Ingrese la cantidad de dinero que recibirá en diciembre: "))

 

paquete_comprado = determinar_paquete(dinero_recibido)

 

print(f"Con ${dinero_recibido}, podrá comprar el siguiente paquete:\n{paquete_comprado}")