#Calcular bono a base de años de trabajo
def calcular_bono_por_antiguedad(años_trabajados):

    if años_trabajados <= 0:

        return 0

    elif años_trabajados <= 10:

        return años_trabajados * 100

    else:

        return 1000
#utiliakmos retunr para mandar como resultado en caso de no obtener el bono


años_trabajados = int(input("Ingrese la cantidad de años trabajados: "))
#creamos unan variable de años trabajados para escribir los año0s trabajados en numero 
bono = calcular_bono_por_antiguedad(años_trabajados)
#la variable bono va a hacer el calculo de los años trabajados a base de cuanto se calcula por edad 
print(f"El bono por antigüedad para {años_trabajados} años trabajados es de ${bono}.")