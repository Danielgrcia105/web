def obtener_calificacion_letra(calificacion):

    if calificacion == 10:

        return "A"

    elif calificacion == 9:

        return "B"

    elif calificacion == 8:

        return "C"

    elif calificacion >= 6:

        return "D"

    else:

        return "F"

 
calificacion_numerica = float(input("Ingrese la calificación (0-10): "))

 
if 0 <= calificacion_numerica <= 10:

    calificacion_letra = obtener_calificacion_letra(calificacion_numerica)

    print(f"La calificación en letra es: {calificacion_letra}")
    #de nuevo utilizamos la cadena para sustituir los valores 

else:

    print("La calificación debe estar en el rango de 0 a 10.")