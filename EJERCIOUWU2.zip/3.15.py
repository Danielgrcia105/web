print ("dia")
def obtener_dia_semana(numero):

    if numero == 1:

        return "L"

    elif numero == 2:

        return "M"

    elif numero == 3:

        return "M"

    elif numero == 4:

        return "J"

    elif numero == 5:

        return "V"

    elif numero == 6:

        return "S"

    elif numero == 7:

        return "D"

    else:

        return "ese dia no existe no viajo entre universos"

 


numero_dia = int(input("Ingrese un número del 1 al 7 para representar un día de la semana: "))

 

if 1 <= numero_dia <= 7:

    dia_semana = obtener_dia_semana(numero_dia)

    print(f"El número {numero_dia} corresponde al día de la semana: {dia_semana}")

else:

    print("Elije del 1-7 no viajo entre universos parra saber el dia a base de tu numerito")
    