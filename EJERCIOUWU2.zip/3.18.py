def calcular_bono_navideño(sueldo, antiguedad):

    if antiguedad > 4 or sueldo < 2000:

        bono = sueldo * 0.25

    else:

        bono = sueldo * 0.20

    return bono

 

# Ejemplo de uso

sueldo_empleado = float(input("Ingrese el sueldo del empleado en pesos: "))

antiguedad_empleado = int(input("Ingrese la antigüedad del empleado en años: "))

 

bono_navideño = calcular_bono_navideño(sueldo_empleado, antiguedad_empleado)

 

print(f"El bono navideño para el empleado es de: ${bono_navideño:.2f}")