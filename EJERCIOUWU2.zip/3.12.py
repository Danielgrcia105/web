def calcular_sueldo_semanal(horas_trabajadas, pago_por_hora):

    if horas_trabajadas <= 40:

        sueldo = horas_trabajadas * pago_por_hora

    elif horas_trabajadas <= 45:

        sueldo = 40 * pago_por_hora + (horas_trabajadas - 40) * (pago_por_hora * 2)

    elif horas_trabajadas <= 50:

        sueldo = 40 * pago_por_hora + 5 * (pago_por_hora * 2) + (horas_trabajadas - 45) * (pago_por_hora * 3)

    else:

        sueldo = "Trabajar más de 50 horas no está permitido"

    return sueldo

 

horas_trabajadas = int(input("Ingrese la cantidad de horas trabajadas en la semana: "))

pago_por_hora = float(input("Ingrese el pago por hora: "))

sueldo_semanal = calcular_sueldo_semanal(horas_trabajadas, pago_por_hora)

print(f"El sueldo semanal del trabajador es: ${sueldo_semanal}")

#en este codigo define la funcion calcular_sueldo_semal para realizar el calculo
#esto a base de el float que sera el pago por hora para poder realzar el calculo