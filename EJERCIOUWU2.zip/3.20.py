
def calcular_precio_ganancia(modelo, talla, cantidad_pantalones):

    # Costo de la tela por metro

    costo_tela_a = 1.50  # en metros

    costo_tela_b = 1.80  # en metros

 

    # Costo de mano de obra

    if modelo == 'A':

        costo_mano_obra = costo_tela_a * 0.80

    else:

        costo_mano_obra = costo_tela_b * 0.95

 

    # Carga por talla 32 y 36

    if talla in ['32', '36']:

        carga_talla = costo_mano_obra * 0.04

    else:

        carga_talla = 0

 

    # Cálculo del costo total

    costo_total = costo_tela_a if modelo == 'A' else costo_tela_b

    costo_total += costo_mano_obra

    costo_total += carga_talla

 

    # Cálculo del precio de venta

    precio_venta = costo_total * 1.30

 

    # Cálculo de la ganancia por los N pantalones

    ganancia_total = precio_venta * cantidad_pantalones

 

    return precio_venta, ganancia_total

 

# Ejmplo aplicado con cadenas

modelo = input("Ingrese el modelo del pantalón (A o B): ").upper()

talla = input("Ingrese la talla del pantalón (30, 32 o 36): ")

cantidad_pantalones = int(input("Ingrese la cantidad de pantalones a producir: "))

 

precio_final, ganancia_total = calcular_precio_ganancia(modelo, talla, cantidad_pantalones)

 

print(f"El precio final de venta por pantalón es: ${precio_final:.2f}")

print(f"La ganancia total por los {cantidad_pantalones} pantalones es: ${ganancia_total:.2f}")