def calcular_costo_pasaje(alumnos):
    print (alumnos)

    if alumnos > 100:

        costo = 20

    elif alumnos >= 50:

        costo = 35

    elif alumnos >= 20:

        costo = 40

    else:

        costo = 70

    costo_total = alumnos * costo

    return costo_total

 #se definen variables y se manda la indicacion requerida don def esto para realizar los calculos ya en la estrucutura 

alumnos = int(input("Ingrese la cantidad de alumnos: "))

costo_total_pasaje = calcular_costo_pasaje(alumnos)
#PONEMOS los calculos de y/O la acccion para indicar la cantridad de los alumnos

print(f"El costo total del pasaje para {alumnos} alumnos es: ${costo_total_pasaje}")
#la parte de la f es para realizar calculos ya que sin este codigo o notaciond e cadena que cumple 
#esta contiene llaves y variables con el fin de realizar cierta accion determinada
#las llaqves sustituyen un valor