def determinar_tipo_vacuna(edad, es_mujer):

    if edad > 70:

        return "C"

    elif edad >= 16 and edad <= 69:

        return "B" if es_mujer else "A"

    else:

        return "A"

 

# ya aplicado con la cadena

edad_persona = int(input("Ingrese la edad de la persona: "))

es_mujer = input("¿Es mujer? (sí: s, no: n): ").lower() == "s"

 

tipo_vacuna = determinar_tipo_vacuna(edad_persona, es_mujer)

 

print(f"La persona debe recibir la vacuna tipo: {tipo_vacuna}")