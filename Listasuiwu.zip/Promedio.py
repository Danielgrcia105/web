
nombres_alumnos = []
notas_alumnos = []
 

num_alumnos = int(input("Ingresa el numero de Estudiantes/Alumnos: "))
 

for i in range(num_alumnos):
    nombre = input(f"Ingrese el nombre del alumno {i + 1}: ")
    nota = float(input(f"Ingrese el prmedio de {nombre}: "))
    
    nombres_alumnos.append(nombre)
    notas_alumnos.append(nota)
    #utilizo append para asignar valores en un conjunto nuevo 
 

promedio_total = sum(notas_alumnos) / num_alumnos


indice_max_promedio = notas_alumnos.index(max(notas_alumnos))
#utilizo indez para obtener un indice en mi variable
nombre_max_promedio = nombres_alumnos[indice_max_promedio]
promedio_maximo = notas_alumnos[indice_max_promedio]

print("Total:")
print(f"El promedio total de notas es: {promedio_total:.2f}")
print(f"El promedio mas alto es de: {nombre_max_promedio} Con un promedio de: {promedio_maximo:.2f}")