num_alumnos = int(input("Ingresa el número de Estudiantes/Alumnos: "))

 
nombres_alumnos = []
notas_alumnos = []
 
for _ in range(num_alumnos):
    nombre = input("Ingrese el nombre del alumno: ")
    nota = float(input(f"Ingrese la nota de {nombre}: "))
    nombres_alumnos.append(nombre)
    notas_alumnos.append(nota)
 
continuar = input("¿Desea agregar más alumnos? (Sí/No): ").lower()
 
while continuar != "no":
    nombre = input("Ingrese el nombre del alumno: ")
    nota = float(input(f"Ingrese la nota de {nombre}: "))
    nombres_alumnos.append(nombre)
    notas_alumnos.append(nota)
    continuar = input("¿Desea agregar más alumnos? (Sí/No): ").lower()
 
num_alumnos = len(nombres_alumnos)
promedio_total = sum(notas_alumnos) / num_alumnos
indice_max_promedio = notas_alumnos.index(max(notas_alumnos))
nombre_max_promedio = nombres_alumnos[indice_max_promedio]
promedio_maximo = notas_alumnos[indice_max_promedio]
 
print("\nResumen:")
print(f"El promedio total de notas es: {promedio_total:.2f}")
print(f"El alumno con el promedio más alto es {nombre_max_promedio} con una nota de {promedio_maximo:.2f}")